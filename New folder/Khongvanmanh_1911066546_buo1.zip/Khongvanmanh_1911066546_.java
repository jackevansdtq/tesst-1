
import java.util.Scanner;

public class Buoi1 {
    public static void main(String []args) {
      
 // bai1.run();
 // bai2.run();
 // bai3.run();
 // bai4.run();
  
       	
			
			
             
    }
		
    

    class bai1 {
    public static void Run{
    	
    	System.out.println("Hello I'm <Manh>.");
        System.out.println("I'm 20 yesrs old.");
        System.out.println("This is my java program.");
    		}
    	
    	
    	
    }
    
    class bai 2{
    	public static void Run{
    		
    	/Scanner sc = new Scanner (System.in);
        int mssv, Tuoi, NamSinh;
        String HoTen;
        float DiemTB;
        
         System.out.print("h�y nh?p m� s? sinh vi�n c?a b?n: ");
        mssv = sc.nextInt();
        System.out.print("h�y nh?p h? v� t�n c?a b?n: ");
        sc.nextLine();
        HoTen = sc.nextLine();
         System.out.print("h�y nh?p tu?i c?a b?n: ");
        Tuoi = sc.nextInt();
        System.out.print("h�y nh?p nam sinh c?a b?n: ");
        NamSinh = sc.nextInt();
        System.out.print("h�y nh?p Di?m TB c?a b?n: ");
        DiemTB = sc.nextFloat();
   
        System.out.println("M� S? SINH VI�N C?A B?N L�: " + mssv);
        System.out.println("H? V� T�N C?A B?N L�: "+ HoTen);
        System.out.println("TU?I C?A B?N L�: " + Tuoi);
        System.out.println("NAM SINH C?A B?N L�: "+ NamSinh);
        System.out.println("�I?M TRUNG B�NH C?A B?N L�: "+ DiemTB);
    		
    		
    	}
    
    	
    }
    
    class  Bai3{
    	public static void Run{
    
    	 int a[], n=0;
       // Scanner scanner = new Scanner(System.in);
           // dieu kien nhap phan tu  
        do {
            System.out.print("Nh?p v�o s? ph?n t? c?a m?ng n: ");
            n = sc.nextInt();
        } while (n < 0);
             
        // kh?i t?o v� c?p ph�t b? nh? cho m?ng
         a = new int[n];
             
        System.out.println("Nh?p c�c ph?n t? cho m?ng: ");
        for (int i = 0; i < n; i++) {
         
            System.out.print("Nh?p ph?n t? th? " +i+ ": ");
            a[i] = sc.nextInt();
        }
        
          	System.out.print("Phan Tu lon nhat trong mang");
          	    
          	    int Max = Numbers[0];
          	   for(int i=0; i < Numbers; i++){
          	   	
          	   	if (Numbers[i]>Max){
          	   		Max = Numbers[i];
          	   
          	   
          	   	} 	
          	   }
          	    	System.out.print("gia tri max la:", + Max);
    }
    	
    	
    
    	}
    	
    
    	
    	class bai4 {
    		public static void Run{
    			
    			int m= 10, n=10;
    			int maTran[i][j]= (int) Math.random()*100);
    			
    		}
    		    for(int i=0; i<m; i++) {
    		    }
    		    for (int j=0; j<n; j++) {
    		      System.out.print(maTran[i][j]+"\t");	
    		    }       
    	}    System.out.prinln();   
    	
    }