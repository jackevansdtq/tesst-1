/**
 * @(#)DemoMang.java
 *
 *
 * @author 
 * @version 1.00 2021/3/23
 */


public class DemoMang {

    public DemoMang() {
    }
    public static void main (String[] args) {
    	Mang m = new Mang();
    	m.input();
    	m.output();
    	m.averageOfOddNumbers();
    	m.findMax();
    	m.sort();
    }
    
}