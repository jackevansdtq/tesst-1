//dinh nghia mot interface shape trong tap tin shape.java
public interface Shape
{
	//Tinh area
	public abstract double area();
	
	//Tinh volume
	public abstract double volume();
	
	//tra ve ten cua shape
	public abstract String getName();
}